// ===== Додайте у main.cpp =====

// 1) нагорі:
#include "cpu.hpp"
#include "alu.hpp"

// 2) одразу після `Memory mem;`
CPU cpu;
cpu.mem = &mem;

// 3) нові гілки диспетчера (поруч із `set`; гілка `reg` — ДАНА в лабі)
} else if (cmd == "reg") {
    std::string r, v;
    long value = 0;
    if (!(words >> r) || !(words >> v) || !parse_number(v, value) || value < 0 ||
        value > 255) {
        std::cout << "usage: reg <a|b> <0..255>\n";
    } else if (r == "a") {
        cpu.a = (Byte)value;
    } else if (r == "b") {
        cpu.b = (Byte)value;
    } else {
        std::cout << "unknown register: " << r << '\n';
    }
} else if (cmd == "regs") {
    dump_regs(cpu);
} else if (cmd == "step") {
    step(cpu);
    dump_regs(cpu);
} else if (cmd == "alu") {
    // alu add 200 100   ->   result=44  Z=0 N=0 C=1
    std::string op, sa, sb;
    long x = 0, y = 0;
    if (!(words >> op) || !(words >> sa) || !parse_number(sa, x) || x < 0 || x > 255) {
        std::cout << "usage: alu <op> <a> [b]\n";
    } else {
        bool two = (op == "add" || op == "sub" || op == "and" || op == "or" || op == "xor");
        if (two && (!(words >> sb) || !parse_number(sb, y) || y < 0 || y > 255)) {
            std::cout << "usage: alu <add|sub|and|or|xor> <a> <b>\n";
        } else {
            Byte A = (Byte)x, B = (Byte)y;
            AluResult r;
            bool ok = true;
            if      (op == "add") r = alu_add(A, B);
            else if (op == "sub") r = alu_sub(A, B);
            else if (op == "and") r = alu_and(A, B);
            else if (op == "or")  r = alu_or(A, B);
            else if (op == "xor") r = alu_xor(A, B);
            else if (op == "not") r = alu_not(A);
            else if (op == "shl") r = alu_shl(A);
            else if (op == "shr") r = alu_shr(A);
            else if (op == "inc") r = alu_inc(A);
            else if (op == "dec") r = alu_dec(A);
            else { ok = false; std::cout << "unknown alu op: " << op << '\n'; }
            if (ok)
                std::cout << "result=" << (int)r.value << "  Z=" << r.f.z
                          << " N=" << r.f.n << " C=" << r.f.c << '\n';
        }
    }
