// alu.hpp — ALU як чисті функції над uint8_t: значення + прапорці.
#pragma once
#include "cpu.hpp"

struct AluResult {
    Byte  value;
    Flags f;      // z, n, c
};

AluResult alu_add(Byte a, Byte b);
AluResult alu_sub(Byte a, Byte b);
AluResult alu_and(Byte a, Byte b);
AluResult alu_or (Byte a, Byte b);
AluResult alu_xor(Byte a, Byte b);
AluResult alu_not(Byte a);
AluResult alu_shl(Byte a);
AluResult alu_shr(Byte a);
AluResult alu_inc(Byte a);   // C тут не рахується — step його не чіпає
AluResult alu_dec(Byte a);   // так само
