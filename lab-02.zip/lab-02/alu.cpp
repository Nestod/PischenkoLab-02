// alu.cpp — кожна функція повертає значення (загорнуте на 8 бітів) і прапорці.
#include "alu.hpp"

#include <cassert>

// Z і N залежать лише від результату — одне місце замість десяти копій.
static AluResult make(Byte value, bool carry) {
    AluResult r;
    r.value = value;
    r.f.z = (value == 0);
    r.f.n = (value & 0x80) != 0;   // старший біт — «знак»
    r.f.c = carry;
    return r;
}

// ADD «на бітах»: повний суматор, біт за бітом. Без оператора `+`.
//   сума біта   = x ^ y ^ перенесення_всередину
//   перенесення = (x & y) | (перенесення_всередину & (x ^ y))
static Byte add_bits(Byte a, Byte b, bool& carry_out) {
    Byte result = 0;
    unsigned carry = 0;
    for (int i = 0; i < 8; ++i) {
        unsigned x = (a >> i) & 1u;
        unsigned y = (b >> i) & 1u;
        result |= (Byte)((x ^ y ^ carry) << i);
        carry = (x & y) | (carry & (x ^ y));
    }
    carry_out = (carry != 0);   // перенесення з сьомого біта
    return result;
}

AluResult alu_add(Byte a, Byte b) {
    bool carry = false;
    Byte value = add_bits(a, b, carry);
    // Debug-перевірка: бітовий ADD мусить збігатись зі звичайним.
    assert(value == (Byte)(a + b));
    assert(carry == ((unsigned)a + (unsigned)b > 0xFF));
    return make(value, carry);
}

AluResult alu_sub(Byte a, Byte b) {
    // C = позика: віднімали більше, ніж було
    return make((Byte)((a - b) & 0xFF), a < b);
}

AluResult alu_and(Byte a, Byte b) { return make((Byte)(a & b), false); }
AluResult alu_or (Byte a, Byte b) { return make((Byte)(a | b), false); }
AluResult alu_xor(Byte a, Byte b) { return make((Byte)(a ^ b), false); }
AluResult alu_not(Byte a)         { return make((Byte)(~a & 0xFF), false); }

AluResult alu_shl(Byte a) {
    return make((Byte)((a << 1) & 0xFF), (a & 0x80) != 0);   // виїхав сьомий біт
}

AluResult alu_shr(Byte a) {
    return make((Byte)(a >> 1), (a & 0x01) != 0);            // виїхав нульовий біт
}

AluResult alu_inc(Byte a) { return make((Byte)((a + 1) & 0xFF), false); }
AluResult alu_dec(Byte a) { return make((Byte)((a - 1) & 0xFF), false); }
