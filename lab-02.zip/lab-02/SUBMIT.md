# Здача Lab 02

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug && cmake --build build
./build/ember            # reg a 200 / reg b 100 / set 0 10 / set 1 0 / step / step / regs
# перевірити: ADD дає A=0x2C Z=0 N=0 C=1, HALT -> наступний step друкує "halted"

git add src README.md
git commit -m "Lab 02: ALU, flags, cpu step"
git tag lab-02
git push && git push --tags
```

Вставте вміст `README-lab-02.md` у README репозиторію.
Перед захистом прожени `checks/lab-02.txt` (якщо є) і трасування руками.
