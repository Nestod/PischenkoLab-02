// cpu.cpp — форма step() з лаби + case для групи 0x1_, decode(), dump_regs().
#include "cpu.hpp"
#include "alu.hpp"

#include <iomanip>
#include <iostream>

// Advanced: байт стану у вільному регіоні (0xB00..0xBFF — «запас»).
// Біти: 0 = Z, 1 = N, 2 = C. Після кожного step дзеркалить прапорці.
const std::uint16_t STATUS_ADDR = 0x0B00;
const Byte STATUS_Z = 1u << 0;
const Byte STATUS_N = 1u << 1;
const Byte STATUS_C = 1u << 2;

static void mirror_flags(CPU& cpu) {
    Byte st = 0;
    if (cpu.f.z) st |= STATUS_Z;
    if (cpu.f.n) st |= STATUS_N;
    if (cpu.f.c) st |= STATUS_C;
    mem_set(*cpu.mem, STATUS_ADDR, st);
}

// M4: розбір опкода масками й зсувом, без «магічного числа на інструкцію».
struct Decoded {
    Byte group;   // старший півбайт: 0x0_ керування, 0x1_ ALU, ...
    Byte index;   // молодший півбайт
};

static Decoded decode(Byte op) {
    Decoded d;
    d.group = (Byte)((op >> 4) & 0x0F);   // старший півбайт
    d.index = (Byte)(op & 0x0F);          // молодший півбайт
    return d;
}

// Записати результат ALU в A і всі три прапорці (ADD SUB AND OR XOR NOT SHL SHR).
static void apply_full(CPU& cpu, const AluResult& r) {
    cpu.a = r.value;
    cpu.f = r.f;
}

// INC/DEC: за ISA чіпають лише Z і N, а C лишається як був.
static void apply_zn(CPU& cpu, const AluResult& r) {
    cpu.a = r.value;
    cpu.f.z = r.f.z;
    cpu.f.n = r.f.n;
}

void step(CPU& cpu) {
    if (cpu.halted) {
        std::cout << "halted\n";
        return;
    }
    Byte op = mem_get(*cpu.mem, cpu.pc);
    Decoded d = decode(op);

    switch (d.group) {
    case 0x0:                                   // керування
        switch (op) {
        case OP_HALT:
            cpu.halted = true;
            cpu.pc += 1;
            break;
        case OP_NOP:
            cpu.pc += 1;
            break;
        default:
            cpu.pc += 1;                        // поки як NOP
            break;
        }
        break;

    case 0x1:                                   // ALU, усі по 1 байту
        switch (op) {
        case OP_ADD: apply_full(cpu, alu_add(cpu.a, cpu.b)); cpu.pc += 1; break;
        case OP_SUB: apply_full(cpu, alu_sub(cpu.a, cpu.b)); cpu.pc += 1; break;
        case OP_AND: apply_full(cpu, alu_and(cpu.a, cpu.b)); cpu.pc += 1; break;
        case OP_OR:  apply_full(cpu, alu_or (cpu.a, cpu.b)); cpu.pc += 1; break;
        case OP_XOR: apply_full(cpu, alu_xor(cpu.a, cpu.b)); cpu.pc += 1; break;
        case OP_NOT: apply_full(cpu, alu_not(cpu.a));        cpu.pc += 1; break;
        case OP_SHL: apply_full(cpu, alu_shl(cpu.a));        cpu.pc += 1; break;
        case OP_SHR: apply_full(cpu, alu_shr(cpu.a));        cpu.pc += 1; break;
        case OP_INC: apply_zn(cpu, alu_inc(cpu.a));          cpu.pc += 1; break;
        case OP_DEC: apply_zn(cpu, alu_dec(cpu.a));          cpu.pc += 1; break;
        default:     cpu.pc += 1; break;        // 0x1A, 0x1B — у наступних лабах
        }
        break;

    default:
        cpu.pc += 1;                            // поки що як NOP; у Lab 4 — помилка
        break;
    }
    mirror_flags(cpu);
}

void dump_regs(const CPU& cpu) {
    std::ios_base::fmtflags old = std::cout.flags();
    std::cout << "PC=0x" << std::hex << std::uppercase << std::setfill('0')
              << std::setw(4) << cpu.pc
              << "  A=0x" << std::setw(2) << (int)cpu.a
              << "  B=0x" << std::setw(2) << (int)cpu.b;
    std::cout.flags(old);
    std::cout << std::setfill(' ')
              << "  Z=" << cpu.f.z << " N=" << cpu.f.n << " C=" << cpu.f.c << '\n';
}
